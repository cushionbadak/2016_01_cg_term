﻿using UnityEngine;
using System.Collections;

public class PublicProp : MonoBehaviour {

    public float interval;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
